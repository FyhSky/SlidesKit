//
//  SlidesKit.h
//  SlidesKit
//
//  Created by Jieyi Hu on 8/29/15.
//  Copyright © 2015 fullstackpug. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SlidesKit.
FOUNDATION_EXPORT double SlidesKitVersionNumber;

//! Project version string for SlidesKit.
FOUNDATION_EXPORT const unsigned char SlidesKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SlidesKit/PublicHeader.h>


